package app.models;

import org.javalite.activejdbc.Model;

/**
 * @author Igor Polevoy: 1/14/12 5:40 PM
 */
public class Person extends Model {
    static{
        validatePresenceOf("first_name", "last_name");
    }

}
