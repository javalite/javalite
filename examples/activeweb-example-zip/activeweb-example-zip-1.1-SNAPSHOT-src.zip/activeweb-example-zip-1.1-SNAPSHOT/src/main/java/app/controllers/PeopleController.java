package app.controllers;

import app.models.Person;
import org.javalite.activeweb.AppController;
import org.javalite.activeweb.annotations.POST;

import java.util.List;

/**
 * @author Igor Polevoy: 1/14/12 5:46 PM
 */
public class PeopleController extends AppController {

    @POST
    public void index(){

        view("people", Person.findAll().orderBy("last_name asc"));
    }


    public void  newForm(){

    }

    @POST
    public void create(){

        Person p = new Person();
        p.fromMap(params1st());

        if(p.save()){
            flash("message", "created a new person");
            redirect(PeopleController.class);
        }else{

            view("errors", p.errors());
            render("new_form");
        }

    }

}
