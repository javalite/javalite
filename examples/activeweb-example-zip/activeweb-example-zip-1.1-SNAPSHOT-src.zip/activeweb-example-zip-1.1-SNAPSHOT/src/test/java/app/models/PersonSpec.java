package app.models;

import org.javalite.activeweb.DBSpec;
import org.junit.Test;

/**
 * @author Igor Polevoy: 1/14/12 5:41 PM
 */
public class PersonSpec extends DBSpec {


    @Test
    public void shouldValidatePresenceOfAttributes(){

        Person p = new Person();
        a(p).shouldNotBe("valid");
        p.set("first_name", "John", "last_name", "Smith");
        a(p).shouldBe("valid");

    }
}
