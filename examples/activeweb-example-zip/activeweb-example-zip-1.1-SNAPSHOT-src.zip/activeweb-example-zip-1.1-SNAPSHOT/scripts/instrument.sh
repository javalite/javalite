mvn -o clean process-classes
